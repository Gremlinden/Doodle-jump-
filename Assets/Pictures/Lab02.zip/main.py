from ast import Expression
from re import L
import sys

import numpy as np
import pandas as pd

from matplotlib.backends.qt_compat import QtWidgets
from matplotlib.backends.backend_qtagg import FigureCanvas
from matplotlib.figure import Figure

from PyQt6.QtWidgets import QSlider, QLineEdit, QLabel
from PyQt6.QtCore import Qt

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self._main = QtWidgets.QWidget()
        self.setCentralWidget(self._main)
        layout = QtWidgets.QVBoxLayout(self._main)
        
        self.sld = QSlider(Qt.Orientation.Horizontal, self)
        self.sld.setRange(0, 100000)
        self.sld.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.sld.setPageStep(5)
        
        self.sld.sliderReleased.connect(self.update_data)
        self.sld.valueChanged.connect(self.update_label)
        
        self.label = QLineEdit('', self)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter| Qt.AlignmentFlag.AlignVCenter)
        self.label.setMinimumWidth(80)
        
        self.label.textChanged.connect(self.update_data)
        
        self.label_1 = QLabel('', self)
        self.label_1.setAlignment(Qt.AlignmentFlag.AlignCenter| Qt.AlignmentFlag.AlignVCenter)
        self.label_1.setMinimumWidth(80)
        
        self.label_2 = QLabel('', self)
        self.label_2.setAlignment(Qt.AlignmentFlag.AlignCenter| Qt.AlignmentFlag.AlignVCenter)
        self.label_2.setMinimumWidth(80)
        
        self.label_3 = QLabel('', self)
        self.label_3.setAlignment(Qt.AlignmentFlag.AlignCenter| Qt.AlignmentFlag.AlignVCenter)
        self.label_3.setMinimumWidth(80)
        
        self.label_4 = QLabel('', self)
        self.label_4.setAlignment(Qt.AlignmentFlag.AlignCenter| Qt.AlignmentFlag.AlignVCenter)
        self.label_4.setMinimumWidth(80)
        
        self.static_canvas_1 = FigureCanvas(Figure())
        self.static_canvas_2 = FigureCanvas(Figure())
        self.static_canvas_3 = FigureCanvas(Figure())
        self.static_canvas_4 = FigureCanvas(Figure())
        
        layout.addWidget(self.sld)
        layout.addWidget(self.label)
        layout.addWidget(self.label_1)
        layout.addWidget(self.static_canvas_1)
        layout.addWidget(self.label_2)
        layout.addWidget(self.static_canvas_2)
        layout.addWidget(self.label_3)
        layout.addWidget(self.static_canvas_3)
        layout.addWidget(self.label_4)
        layout.addWidget(self.static_canvas_4)
        self._static_ax_1 = self.static_canvas_1.figure.subplots()
        self._static_ax_2 = self.static_canvas_2.figure.subplots()
        self._static_ax_3 = self.static_canvas_3.figure.subplots()
        self._static_ax_4 = self.static_canvas_4.figure.subplots()
        
        self._static_ax_1.set_xlim(-500, 500)
        self._static_ax_1.set_ylim(-500, 500)
        self._static_ax_1.set_aspect('equal', adjustable='box')
        self._static_ax_2.set_xlim(-500, 500)
        self._static_ax_2.set_ylim(-500, 500)
        self._static_ax_2.set_aspect('equal', adjustable='box')
        self._static_ax_3.set_xlim(-500, 500)
        self._static_ax_3.set_ylim(-500, 500)
        self._static_ax_3.set_aspect('equal', adjustable='box')
        self._static_ax_4.set_xlim(-500, 500)
        self._static_ax_4.set_ylim(-500, 500)
        self._static_ax_4.set_aspect('equal', adjustable='box')
        
    def update_data(self, val=None):
        if val:
            try:
                value = int(val)
            except Exception:
                value = 0
        else:
            value = int(self.sld.value())
        self.result(value)
    
    def update_label(self, value):
        self.label.setText(str(value))
        
    
    def generate_data(self, N: int):
        X = np.random.normal(0, 10, N)
        y = np.random.normal(0, 10, N)
        return X, y

    def funnel(self, Xs, rule):
        x, rxs = 0, []

        for sample in Xs:
            rxs.append(x + sample)
            x = rule(x, sample)
        
        return rxs

    def experiment(self, X, y, rule):
        x_res = self.funnel(X, rule)
        y_res = self.funnel(y, rule)
        mean = np.mean(x_res), np.mean(y_res)
        std = np.std(x_res), np.mean(y_res)
        return (x_res, y_res), mean, std
    
    def result(self, value):
        X, y = self.generate_data(value)
        
        # Не двигать воронку
        res, mean_1, std_1 = self.experiment(X, y, lambda z, dz: 0)
        
        self._static_ax_1.cla()
        self._static_ax_1.set_xlim(-500, 500)
        self._static_ax_1.set_ylim(-500, 500)
        self._static_ax_1.set_aspect('equal', adjustable='box')
        self._static_ax_1.scatter(res[0], res[1])
        self._static_ax_1.figure.canvas.draw()
        
        # Передвинуть воронку, чтобы компенсировать ошибку предыдущего запуска
        res, mean_2, std_2 = self.experiment(X, y, lambda z, dz: -dz)
        
        self._static_ax_2.cla()
        self._static_ax_2.set_xlim(-500, 500)
        self._static_ax_2.set_ylim(-500, 500)
        self._static_ax_2.set_aspect('equal', adjustable='box')
        self._static_ax_2.scatter(res[0], res[1])
        self._static_ax_2.figure.canvas.draw()

        # Передвинуть воронку от мешени с учетом предыдущей ошибки
        res, mean_3, std_3 = self.experiment(X, y, lambda z, dz: -(z + dz))

        self._static_ax_3.cla()
        self._static_ax_3.set_xlim(-500, 500)
        self._static_ax_3.set_ylim(-500, 500)
        self._static_ax_3.set_aspect('equal', adjustable='box')
        self._static_ax_3.scatter(res[0], res[1])
        self._static_ax_3.figure.canvas.draw()
        
        # Установить воронку над местом падения шарика
        res, mean_4, std_4 = self.experiment(X, y, lambda z, dz: z + dz)
        
        self._static_ax_4.cla()
        self._static_ax_4.set_xlim(-500, 500)
        self._static_ax_4.set_ylim(-500, 500)
        self._static_ax_4.set_aspect('equal', adjustable='box')
        self._static_ax_4.scatter(res[0], res[1])
        self._static_ax_4.figure.canvas.draw()
        
        self.label_1.setText(f"Mean x, y: {mean_1[0]:.2f}, {mean_1[1]:.2f}\nStd x, y: {std_1[0]:.2f}, {std_1[0]:.2f}")
        self.label_2.setText(f"Mean x, y: {mean_2[0]:.2f}, {mean_2[1]:.2f}\nStd x, y: {std_2[0]:.2f}, {std_2[0]:.2f}")
        self.label_3.setText(f"Mean x, y: {mean_3[0]:.2f}, {mean_3[1]:.2f}\nStd x, y: {std_3[0]:.2f}, {std_3[0]:.2f}")
        self.label_4.setText(f"Mean x, y: {mean_4[0]:.2f}, {mean_4[1]:.2f}\nStd x, y: {std_4[0]:.2f}, {std_4[0]:.2f}")

if __name__ == '__main__':
    qapp = QtWidgets.QApplication.instance()
    if not qapp:
        qapp = QtWidgets.QApplication(sys.argv)

    app = MainWindow()
    app.show()
    app.activateWindow()
    app.raise_()
    qapp.exec()